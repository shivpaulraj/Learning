import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  

  public form = new FormGroup({
    name: new FormControl('', Validators.required),
    });
    
    submit(event) {
      var a = 1;//Example for Var vs Let
      var b = 2;
      if(a===1){
        var a = 3;
        console.log(a);
      }
      console.log(a);
      
      let c = 1;
      let d = 2;
      if(c===1){
        let c = 3;
        console.log(c);
      }
      console.log(c);


    console.log(event);
    console.log(this.form.controls.name.value);
    }
   
  constructor() { }
 
  ngOnInit(): void {
  }

}
